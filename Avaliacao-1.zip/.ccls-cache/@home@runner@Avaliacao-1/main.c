#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {

  int portaPremiada, portaEscolhida, portaVazia;

  printf("Bem-vindo ao jogo de Monty Hall!\n");

  printf("Escolha uma porta entre 1 e 3: ");
  scanf("%d", &portaEscolhida);

  srand(time(NULL));
  portaPremiada = rand() % 3 + 1;
  do {
    if (portaVazia != portaPremiada) {
      printf("A porta %d não contém o prêmio.\n", portaVazia);
    }
    printf("Voce deseja trocar de porta? (1 para sim, 0 para nao): ");
    int trocarPorta;
    scanf("%d", &trocarPorta);
    if (trocarPorta == 0) {
      printf("Voce ganhou!\n");
    } else {
      printf("Voce perdeu!\n");
    }

  } while (portaVazia != portaPremiada);
  return 0;
}
